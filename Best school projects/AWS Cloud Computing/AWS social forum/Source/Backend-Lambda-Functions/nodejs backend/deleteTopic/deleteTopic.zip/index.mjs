import mysql from 'mysql2/promise';

export const handler = async (event) => {
  const dbConfig = {
    host: 'forum-database.ci6qmqse2nc9.us-east-1.rds.amazonaws.com',
    user: 'admin',
    password: 'testtest',
    database: 'forum-database',
  };

  let connection;

  try {
    connection = await mysql.createConnection(dbConfig);

    const requestBody = event;

    // Extract and validate the required fields
    const { topic_id, user_id } = requestBody;

    if (!topic_id || !user_id) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Missing required fields: topic_id, user_id'}),
      };
    }


     // Step 1: check if user is admin 
     const [rows] = await connection.execute('SELECT admin FROM users WHERE user_id = ?', [user_id]);


     if (rows[0].admin !== 1) {
       return {
         statusCode: 403,
         body: JSON.stringify({ error: 'Unauthorized: Only Administrators can delete topics' }),
       };
     }

    // Step 2: Perform the delete operation
    const [result] = await connection.execute('DELETE FROM topics WHERE topic_id = ?', [topic_id]);

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'topic deleted successfully' }),
    };
  } catch (error) {
    console.error('Database deletion error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Failed to delete topic', details: error.message }),
    };
  } finally {
    if (connection) {
      await connection.end();
    }
  }
};
